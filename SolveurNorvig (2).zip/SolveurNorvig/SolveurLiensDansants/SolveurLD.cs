﻿using System;
using System.Collections.Generic;
using System.Text;
using Noyau;

namespace SolveurLiensDansants
{
    class SolveurLD : ISudokuSolveur
    {
        public Sudoku ResoudreSudoku(Sudoku s)
        {
            return s;
        }
    }
}
